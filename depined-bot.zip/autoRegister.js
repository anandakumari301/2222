import { saveToFile, delay, readFile } from './utils/helper.js';
import log from './utils/logger.js';
import Mailjs from '@cemalgnlts/mailjs';
import { registerUser, confirmUserRef } from './utils/api.js';

const mailjs = new Mailjs();

const main = async () => {
    log.info(`Starting auto-register bot...`);
    await delay(3);

    const referralCodes = await readFile("referrals.txt");
    if (referralCodes.length === 0) {
        log.warn("No referral codes found in referrals.txt. Exiting...");
        return;
    }

    for (const refCode of referralCodes) {
        try {
            let account = await mailjs.createOneAccount();
            while (!account?.data?.username) {
                log.warn('Failed to generate email, retrying...');
                await delay(3);
                account = await mailjs.createOneAccount();
            }

            const email = account.data.username;
            const password = account.data.password;
            log.info(`Registering email: ${email}`);

            let regResponse = await registerUser(email, password, null);
            if (!regResponse?.data?.token) {
                log.error(`Registration failed for ${email}, skipping...`);
                continue;
            }

            const userToken = regResponse.data.token;
            log.info(`Confirming referral: ${refCode}`);
            let confirm = await confirmUserRef(userToken, refCode);

            if (!confirm?.data?.token) {
                log.error(`Referral confirmation failed for ${email}, skipping...`);
                continue;
            }

            await saveToFile("accounts.txt", `${email}|${password}`);
            await saveToFile("tokens.txt", `${confirm.data.token}`);

        } catch (err) {
            log.error('Error in registration process:', err.message);
        }
    }
};

process.on('SIGINT', () => {
    log.warn('Process interrupted. Exiting...');
    process.exit();
});

main();

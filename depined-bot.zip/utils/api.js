import fetch from 'node-fetch';
import randomUseragent from 'random-useragent';
import log from './logger.js';
import { newAgent } from './helper.js';

const headers = {
    'accept': 'application/json',
    'user-agent': randomUseragent.getRandom(),
    'Origin': "https://app.depined.org",
    'Content-Type': 'application/json',
};

const fetchWithTimeout = async (url, options = {}, timeout = 60000) => {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(id);
        if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
        return response;
    } catch (error) {
        clearTimeout(id);
        log.error(`Fetch failed for ${url}: ${error.message}`);
        return null;
    }
};

export const registerUser = async (email, password, proxy) => {
    const url = 'https://api.depined.org/api/user/register';
    const agent = newAgent(proxy);
    try {
        const response = await fetchWithTimeout(url, {
            method: 'POST',
            headers,
            body: JSON.stringify({ email, password }),
            agent,
        });
        return response ? response.json() : null;
    } catch (error) {
        log.error('Error registering user:', error.message);
        return null;
    }
};

export const confirmUserRef = async (token, referral_code, proxy) => {
    const url = 'https://api.depined.org/api/access-code/referal';
    const agent = newAgent(proxy);
    try {
        const response = await fetchWithTimeout(url, {
            method: 'POST',
            headers: { ...headers, 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ referral_code }),
            agent,
        });
        return response ? response.json() : null;
    } catch (error) {
        log.error('Error confirming referral:', error.message);
        return null;
    }
};

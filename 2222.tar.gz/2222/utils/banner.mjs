export default `
----------------------------------------------------
   WELCOME TO AUTO REFERRAL SCRIPT
   Created with ❤️ for automating referral tasks
----------------------------------------------------
`;

import { saveToFile, delay } from './utils/helper.mjs';
import { fetchReferralCode, createUserProfile } from './utils/api.mjs';
import { displayBanner } from './utils/banner.mjs';

displayBanner();

const TOKENS_FILE = 'tokens.txt';

async function main() {
  console.info("[INFO] Processing auto register... (CTRL + C to exit)");
  const tokens = [];
  
  if (tokens.length === 0) {
    console.warn("[WARN] No tokens found in tokens.txt. Exiting...");
    return;
  }

  for (const token of tokens) {
    const referralCode = await fetchReferralCode();
    console.info(`[INFO] Found new active referral code: ${referralCode}`);
    
    const email = Math.random().toString(36).substring(2, 8) + "@e-record.com";
    console.info(`[INFO] Trying to register email: ${email}`);
    
    await createUserProfile(email, referralCode);
    await delay(3000); // 3-second delay between registrations
  }
}

main();

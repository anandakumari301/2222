export function displayBanner() {
  console.info(`
----------------------------------------------------
   WELCOME TO AUTO REFERRAL SCRIPT
   Created with ❤️ for automating referral tasks
----------------------------------------------------
`);
}

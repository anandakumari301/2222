import axios from 'axios';

export async function fetchReferralCode() {
  try {
    const response = await axios.get('https://api.depined.org/api/referrals/stats');
    return response.data.code;
  } catch (error) {
    console.error(`Fetch failed for referral code: ${error.message}`);
    return null;
  }
}

export async function createUserProfile(email, referralCode) {
  try {
    const payload = { email, referralCode };
    const response = await axios.post('https://api.depined.org/api/register', payload);
    console.info(`[INFO] Profile created successfully for ${email}`);
  } catch (error) {
    console.error(`[ERROR] Failed to create profile for ${email}: ${error.message}`);
  }
}

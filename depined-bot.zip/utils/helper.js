import { HttpsProxyAgent } from 'https-proxy-agent';
import { SocksProxyAgent } from 'socks-proxy-agent';
import fs from 'fs/promises';
import log from './logger.js';

export function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms * 1000));
}

export async function saveToFile(filename, data) {
    try {
        await fs.appendFile(filename, `${data}\n`, 'utf-8');
        log.success(`Saved data to ${filename}`);
    } catch (error) {
        log.error(`Failed to save data to ${filename}: ${error.message}`);
    }
}

export async function readFile(pathFile) {
    try {
        const data = await fs.readFile(pathFile, 'utf8');
        return data.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    } catch (error) {
        log.error(`Error reading file: ${error.message}`);
        return [];
    }
}

export const newAgent = (proxy = null) => {
    if (proxy) {
        if (proxy.startsWith('http://')) return new HttpsProxyAgent(proxy);
        if (proxy.startsWith('socks4://') || proxy.startsWith('socks5://')) return new SocksProxyAgent(proxy);
        log.warn(`Unsupported proxy type: ${proxy}`);
    }
    return null;
};

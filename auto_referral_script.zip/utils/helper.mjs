import fs from 'fs/promises';

export async function saveToFile(fileName, data) {
  await fs.writeFile(fileName, data);
}

export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
